function toggleOrder(){
    var hide = document.getElementById("preorder");
    if (hide.style.display === "block"){
        hide.style.display = "none";
    } else {
        hide.style.display = "block";
    }
}

function toggleBio(){
    var hide = document.getElementById("bioForm");
    if (hide.style.display === "block"){
        hide.style.display = "none";
    } else {
        hide.style.display = "block";
    }
}